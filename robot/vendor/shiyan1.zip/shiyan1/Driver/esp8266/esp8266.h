#ifndef __ESP8266_H
#define __ESP8266_H

#include "stm32f10x.h"
#include <stdio.h>
#include <string.h>

// ���Ͷ���
typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;
typedef volatile unsigned int vu32;

// ������ָ��ṹ��
typedef struct {
    int startX;
    int startY;
    int endX;
    int endY;
    int signal;
    u8  is_new_cmd;
} RobotCommand_t;

// ȫ�ֱ����ⲿ����
extern RobotCommand_t g_RobotCmd;
extern u8 USART2_RX_BUF[512];
extern u8 USART2_RX_CNT;
extern u8 AT_STEP;
extern u8 ESP_OK_FLAG;
extern u32 step_timeout;

// �ײ������������
void Delay_ms(u16 ms);
void MY_NVIC_PriorityGroupConfig(u8 NVIC_Group);
void MY_NVIC_Init(u8 pre,u8 sub,u8 ch,u8 group);
void USART1_Init(u32 pclk2,u32 baud);
void USART2_Init(u32 pclk1,u32 baud);
void SysTick_Init(void);
void USART1_SendStr(char *str);
void USART2_SendStr(char *str);
void Clear_Buf(void);
void Check_OK(void);

// ESP8266ҵ����⺯��
void ESP8266_Init(void);
void ESP8266_Task(void);
void ESP8266_Send_Result(u8 success_flag);

#endif
