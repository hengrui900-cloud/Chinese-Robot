#include "stm32f10x.h"  
#include "esp8266.h"
#include "pump_valve.h"
#include "motor.h"
#include "ik.h"

// ����ת�ǶȺ�
#define RAD_TO_DEG(rad)  ((rad) * 180.0f / 3.1415926535f)

// ===================== ״̬�붨�� =====================
typedef enum {
    SYS_IDLE        = 0,
    SYS_RUNNING     = 1,
    SYS_IK_ERROR    = 2,
    SYS_CMD_ERROR   = 3,
    SYS_SAFE_STOP   = 4,
    SYS_FINISH      = 5
} SystemState_TypeDef;

volatile SystemState_TypeDef g_SystemState = SYS_IDLE;

// ===================== ��ȫͣ�� =====================
void System_SafeStop(void)
{
		Motor_StopAll();	
    Pump_Off();
    Valve_Off();
    
    g_SystemState = SYS_SAFE_STOP;
    USART1_SendStr("\r\n!!! ϵͳ��ȫͣ�������е��/�����ѹر�\r\n");
}

// ��������
void sport1(SCARA_Motion_t result){
    if(g_SystemState == SYS_SAFE_STOP) return;
    USART1_SendStr("\r\n===== ִ�� sport1 =====\r\n");
    USART1_SendStr("\r\n���1\r\n");
    Motor_M1_Rotate(result.dq1_rel_deg);
    USART1_SendStr("\r\n���2\r\n");
    Motor_M2_Rotate(result.dq2_rel_deg);
    Delay_ms(500);
    USART1_SendStr("\r\n���3\r\n");
    Motor_M3_RunPulse(1000, 1);
	  USART1_SendStr("\r\n�����Ų���1\r\n");
	  Pump_On();
    Valve_On();
	  Delay_ms(500);
    USART1_SendStr("\r\n������\r\n");
    Pump_Off();
    Valve_Off();
    USART1_SendStr("\r\n��ʼת���3\r\n");
    Motor_M3_RunPulse(1000, 0);
}

void sport2(SCARA_Motion_t result){
    if(g_SystemState == SYS_SAFE_STOP) return;
    USART1_SendStr("\r\n===== ִ�� sport2 =====\r\n");
    USART1_SendStr("\r\n���1\r\n");
    Motor_M1_Rotate(result.dq1_rel_deg);
    USART1_SendStr("\r\n���2\r\n");
    Motor_M2_Rotate(result.dq2_rel_deg);
    Delay_ms(500);
    USART1_SendStr("\r\n��ʼת���3\r\n");
    Motor_M3_RunPulse(1000, 1);
    USART1_SendStr("\r\n�����Ų���1\r\n");
    Valve_On();
    Delay_ms(200);
    USART1_SendStr("\r\n������\r\n");
    Valve_Off();
    USART1_SendStr("\r\n��ʼת���3\r\n");
    Motor_M3_RunPulse(1000, 0);
}

void sport3(SCARA_Motion_t result){
    if(g_SystemState == SYS_SAFE_STOP) return;
    USART1_SendStr("\r\n===== ִ�� sport3�����ֱۣ�����M3��=====\r\n");
    USART1_SendStr("\r\n���1\r\n");
    Motor_M1_Rotate(result.dq1_rel_deg);
    USART1_SendStr("\r\n���2\r\n");
    Motor_M2_Rotate(result.dq2_rel_deg);
    Delay_ms(500);
}

void Execute_Chess_Move(float start_x, float start_y, float end_x, float end_y, int step_idx, int signal) {
    if(g_SystemState == SYS_SAFE_STOP) return;

    SCARA_Params_t my_robot = {220.0f, 220.0f, 160.0f, -40.0f};
    SCARA_Point_t p_start = {start_x, start_y};
    SCARA_Point_t p_end = {end_x, end_y};
    SCARA_Motion_t result;

    uint8_t err = SCARA_Calc_Movement(p_start, p_end, my_robot, &result);

    if (err == 0) {
        USART1_SendStr("q1: ");
        USART1_SendFloat(result.dq1_rel_deg);
        USART1_SendStr(" | q2: ");
        USART1_SendFloat(result.dq2_rel_deg);
        USART1_SendStr("\r\n");
        Delay_ms(300);

        if(signal == 0){
            if(step_idx == 0) sport1(result);
            else if(step_idx == 1) sport2(result);
            else sport3(result);
        } else {
            if(step_idx == 0 || step_idx == 2) sport1(result);
            else if(step_idx == 1 || step_idx == 3) sport2(result);
            else sport3(result);
        }
    } else {
        USART1_SendStr("\r\nIK �������\r\n");
        g_SystemState = SYS_IK_ERROR;
        System_SafeStop();
    }
}

int main(void)
{
    SystemInit();
    
    ESP8266_Init();  
    Pump_Valve_PWM_Init();
    Motor_InitAll();
	
    SCARA_Params_t arm_params = {220.0f, 220.0f};
    float delta_q1_rad = 0.0f;
    float delta_q2_rad = 0.0f;
    
    g_SystemState = SYS_IDLE;
    USART1_SendStr("\r\nϵͳ��ʼ����ɣ�״̬������\r\n");
    
    while(1)
    {
        ESP8266_Task();

        if(g_SystemState == SYS_SAFE_STOP){
            Delay_ms(100);
            continue;
        }

        if(g_RobotCmd.is_new_cmd == 1)
        {
            g_RobotCmd.is_new_cmd = 0;
            g_SystemState = SYS_RUNNING;
            USART1_SendStr("\r\n��ʼִ���˶�...״̬��������\r\n");
            Delay_ms(500);

            int pos0[2][4]={{380,g_RobotCmd.startX,g_RobotCmd.endX,380},{180,g_RobotCmd.startY,g_RobotCmd.endY,180}};
            int pos1[2][6]={{380,g_RobotCmd.endX,-60,g_RobotCmd.startX,g_RobotCmd.endX,380},{180,g_RobotCmd.endY,180,g_RobotCmd.startY,g_RobotCmd.endY,180}};
			
            int i=0;
            u8 exec_result = 1;
            
            if(g_RobotCmd.signal == 0)
            {
                for(i=0;i<3;i++)
                {
                    Execute_Chess_Move(pos0[0][i], pos0[1][i], pos0[0][i+1], pos0[1][i+1], i, 0);
                }
            }
            else if(g_RobotCmd.signal == 1)
            {
                for(i=0;i<5;i++)
                {
                    Execute_Chess_Move(pos1[0][i], pos1[1][i], pos1[0][i+1], pos1[1][i+1], i, 1);
                }
            }
            else
            {
                USART1_SendStr("\r\nָ���źŴ���\r\n");
                g_SystemState = SYS_CMD_ERROR;
                System_SafeStop();
                exec_result = 0;
            }

            if(g_SystemState != SYS_SAFE_STOP)
            {
                g_SystemState = SYS_FINISH;
                USART1_SendStr("\r\n����ִ����ɣ�״̬�����\r\n");
            }
            else
            {
                exec_result = 0;
            }

         
            ESP8266_Send_StateAndResult(exec_result);
            g_SystemState = SYS_IDLE;
        }
    }
}


